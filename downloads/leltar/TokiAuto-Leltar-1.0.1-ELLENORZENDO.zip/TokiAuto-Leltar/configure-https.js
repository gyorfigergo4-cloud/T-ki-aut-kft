'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { isIP } = require('node:net');
function makeConfig(ip, storage) {
  if (isIP(ip) !== 4) throw Error('Érvényes IPv4-cím szükséges.');
  const root = JSON.stringify(storage.replaceAll('\\', '/'));
  return `{\n    admin off\n    auto_https disable_redirects\n    skip_install_trust\n    storage file_system {\n        root ${root}\n    }\n}\nhttps://${ip}:3443 {\n    tls internal\n    reverse_proxy 127.0.0.1:3210\n}\n`;
}
if (require.main === module) {
  const addresses = Object.values(os.networkInterfaces()).flat().filter(i => i.family === 'IPv4' && !i.internal).map(i => i.address);
  const ip = process.argv[2];
  if (!ip || !addresses.includes(ip)) {
    console.error('A bolti hálózat helyi IPv4-címét add meg. Elérhető címek:', addresses.join(', '));
    console.error('Példa: node configure-https.js 192.168.1.10');
    process.exitCode = 1;
  } else {
    const dir = path.join(__dirname, 'data'); fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'Caddyfile'), makeConfig(ip, path.join(dir, 'https')));
    console.log(`Konfiguráció elkészült. Telefonos cím: https://${ip}:3443`);
    console.log('Nem indítottam szolgáltatást, nem töltöttem le programot és nem telepítettem tanúsítványt.');
  }
}
module.exports = { makeConfig };
