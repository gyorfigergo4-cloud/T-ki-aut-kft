# Kiadási állapot: csak helyi előkészítés, nem ellenőrzött kiadás

Az 1.0.0 ZIP-re a felhasználó Windows Defendere `Trojan:Script/Sabsik.FL.A!ml` jelzést adott. `DidThreatExecute: False` szerepelt a kapott jelentésben. A képek a ZIP-et nevezték meg, nem az azt kiváltó belső fájlt. A pontos ok és a téves riasztás lehetősége nincs igazolva. Az eredeti letöltést visszavontuk; régi Git-verzióból se használd.

Az 1.0.1-review.1 helyi forrásváltozat eltávolítja az automatikus PowerShell-telepítőt, az execution policy felülírásával indító CMD-t és a mellékelt futtatható programokat. Nem indítunk helyettük rejtett parancsokat, és nem kapcsolunk ki vírusvédelmet. A régi eredeti ZIP a vizsgálathoz helyben megmarad. Ezek elővigyázatossági változtatások, nem bizonyítják a riasztás okát vagy annak megszűnését.

A kiszolgálóhoz az operációs rendszerre külön, hivatalos forrásból telepített Node.js szükséges. A telefonos HTTPS-hez külön telepített Caddy vagy más megbízható HTTPS-proxy kell. A forráscsomag tartalmazza a változatlan, olvasható ZXing böngészős könyvtárat a licencekkel és eredetadatokkal; az alkalmazás futásához npm-telepítés nem szükséges.

## Meglévő ellenőrzés

- Node-integrációs tesztek: leltár, termékek, visszavonás, párhuzamos műveletek és ismételt kérések.
- Két elkülönített mobilméretű Chromium: a számlálási munkafolyamat és valódi EAN-13-kép dekódolása.
- Kiadáscsomag-ellenőrzés: nincsenek mellékelt futtatható binárisok, shell-/PowerShell-indítók, helyi adatok vagy kulcsok.

Ezek nem vírusvizsgálatok. Windows Defender ebben a Linux-környezetben nem fut; a felülvizsgált csomag Defender-eredménye még nem áll rendelkezésre. A végleges ZIP-en friss Windows Defenderrel (rögzített motor- és adatbázisverzióval) végzett vizsgálat és a riasztás tisztázása szükséges. Jelzés esetén a pontos belső fájlt is azonosítani kell; Microsoft-beküldés csak külön engedéllyel történhet. Ne nevezd át vagy csomagold újra a fájlokat a felismerés megkerülése céljából.

A helyi áttekintő ZIP-et a `python3 scripts/package-source.py` készíti. Nem tölt fel semmit. A felhasználó külön kérésére a forráscsomag kizárólag vizsgálatra megosztható, egyértelmű ELLENŐRZENDŐ jelöléssel. Ez nem jóváhagyott, használatra ajánlott kiadás. A régi vírusirtói tiltást nem szabad megkerülni.
