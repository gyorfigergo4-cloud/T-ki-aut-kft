# Töki Autó · Leltár – felülvizsgált forrásváltozat

**Nem Windows Defenderrel ellenőrzött kiadás.** Az 1.0.0 ZIP visszavonva marad; azt ne állítsd vissza. Ez az útmutató a felülvizsgálatot végző fejlesztőnek/rendszergazdának készült, nem a korábbi tiltás megkerüléséhez. Részletek: `ELLENORZES.md`.

## Kézi telepítés az ellenőrzést követően

Egy Windows 11 x64 központ, két telefon a bolti wifin, négy munkatárs közös bolti belépőkóddal. A névválasztás nem személyre szóló hitelesítés. A szolgáltatást ne tedd nyilvánosan elérhetővé.

1. A Node.js 24 LTS-t külön a hivatalos **https://nodejs.org/** oldalról kell telepíteni. A forráscsomag nem tartalmaz és nem tölt le futtatókörnyezetet.
2. Az alkalmazás mappájában nyitott terminálban: `node server.js`. A futtatáshoz **nem kell npm-telepítés**. A szerver Node-beépített modulokat használ, a böngészős ZXing-könyvtár mellékelve van.
3. Helyi teszt: `http://127.0.0.1:3210`. A terminálban megjelenő bolti kóddal és saját névvel lehet belépni. A központ és terminál használat közben maradjon bekapcsolva. Leállítás: Ctrl+C.

A vizsgálatot az indítás előtt kell elvégezni; találat esetén nincs engedélyezés, kizárás vagy visszaállítás. A binárisok hiánya nem bizonyít vírusmentességet.

## Telefonos kamera: külön HTTPS

A kamera a bolti IP-címen megbízható HTTPS-t igényel. Ezeket a lépéseket az ellenőrzést követően rendszergazda végezze el:

1. Telepítsen Caddyt külön, hivatalos forrásból (**https://caddyserver.com/**), vagy használjon más megbízható HTTPS-proxyt. Caddy-binárist és letöltőszkriptet nem mellékelünk.
2. A gép bolti hálózathoz tartozó címével például: `node configure-https.js 192.168.1.10`. Ez csak `data/Caddyfile` konfigurációt ír, nem indít szolgáltatást és nem módosít tanúsítványbizalmat. A routerben állandó DHCP-cím javasolt.
3. Szerverindítás: `node server.js --https-proxy`. A szerver továbbra is loopbacken figyel.
4. Második terminálban a külön telepített Caddyvel: `caddy run --config data/Caddyfile --adapter caddyfile`. Példabeli telefonos cím: `https://192.168.1.10:3443`.
5. A tűzfalon csak a privát bolti hálózat/helyi alhálózat felől engedélyezze a Caddy TCP 3443-as portját. A 3210-es belső portot nem kell megnyitni. A vendégwifi eszközelkülönítése akadályozhatja a kapcsolatot.
6. A Caddy által létrehozott `data/https/pki/authorities/local/root.crt` **nyilvános** gyökértanúsítványt kell a telefonoknak átadni. A privát kulcsokat és a `data/https` többi fájlját ne ossza meg. Automatikus bizalmi telepítés nincs (`skip_install_trust`).
7. iPhone: a saját bolti tanúsítvány profiljának telepítése után Beállítások → Általános → Infó → Tanúsítványbizalmi beállítások alatt a teljes bizalom engedélyezendő. Android: Biztonság → Titkosítás és hitelesítő adatok → CA-tanúsítvány telepítése (készülékfüggő). Windows böngészőnél a saját gyökértanúsítvány a jelenlegi felhasználó megbízható gyökértanúsítványai közé vehető fel.
8. A HTTPS-oldalon külön engedélyezendő a kamera. A tanúsítványhibán való átkattintás helyett szabályos bizalmi beállítás kell; TLS- vagy vírusvédelmet nem kapcsolunk ki.

Leállítás: mindkét terminálban Ctrl+C. A Windowsos indulás és a fizikai iPhone/Android kamera helyszíni próbája még szükséges.

## Használat

Új leltárnál a számlálás nulla; a terméktár és a régi leltárak megmaradnak. Egyszerre egy leltár nyitott. Minden elfogadott csippantás +1. A következő azonos darab előtt a kódot legalább kb. egy másodpercre vedd ki a kamera képéből. A hang és rezgés böngészőfüggő; a sikerüzenet és a számláló az irányadó. Kézi/billentyűzetként működő olvasónál minden Enter szándékos +1.

Ismeretlen kódnál név, gyártó és cikkszám vihető fel az első darabbal együtt. A webes keresés külön keresőoldalt nyit, automatikus beszállítói adatkapcsolat nincs. A mintatermék FILTRON OP 612 / 5904608006127, előre megszámolt darab nélkül.

A saját beolvasás visszavonható. A két telefon közös listába számol. Hálózati hibánál a függő kérést az újrapróbálás gombbal rendezd; ne számold újra, ne töröld a böngészőadatokat és ne válts munkatársat/eszközt. Az ismételt kérés azonosítója megmarad, nem dupláz. Offline számlálás nincs. Lezárás előtt mindkét munkatárs rendezze a függő kéréseit. A lezárt leltár megtekinthető és exportálható.

Excel-export: UTF-8, pontosvesszős CSV. A vonalkódoszlopot szövegként importáld a kezdő nullák megőrzéséhez. Ez időszakos leltár; a napi bevételezés és eladás még nincs benne.

## Mentés

Az adatok `data/inventory.json` alatt vannak. A napi első változtatás előtti állapot `data/backups` alá kerül. A teljes JSON-mentés a termékeket, leltárakat, munkatársakat és műveleteket menti; a belépőkódot nem. Rendszeresen külön eszközre is ments. A `data/access.json` belépőkódját ne oszd meg; helyi adat és privát kulcs nem kerülhet kiadásba.

Visszaállítás: szerverleállítás, a jelenlegi adatfájl megőrzése külön néven, majd a teljes mentés másolása `data/inventory.json` helyére. Újraindítás után ellenőrizd a leltárakat és mennyiségeket. Egy adatkönyvtárhoz egy szerver fusson.

## Fejlesztői ellenőrzés

Használd a meglévő checkoutot; külön worktree nem kell. Node.js 22.22.2+ vagy 24 LTS, npm a fejlesztői eszközökhöz. A program futtatásához nincs npm-függőség. A `public/vendor` alatt a változatlan, olvasható ZXing UMD-könyvtár, licencek és SHA256-eredetadatok szerepelnek.

```sh
cd inventory
npm ci --ignore-scripts
npm test
npm run test:browser
```

A böngészőteszt Linuxon `/usr/bin/chromium`-ot használ, más útvonalhoz `CHROMIUM_PATH` állítható. Az `npm run vendor` a lockfile alapján telepített ZXing olvasható könyvtárát és licenceit másolja. Az `npm run package:review` Python 3-mal helyi áttekintő ZIP-et készít; nem publikál. Ezek nem vírusvizsgálatok.

Közvetlen TLS-hez `INVENTORY_TLS_CERT` és `INVENTORY_TLS_KEY` használható. A `HOST`, `PORT`, `INVENTORY_DATA_DIR`, `INVENTORY_ACCESS_CODE`, `INVENTORY_HTTPS=1` felülírások megmaradnak. A program nem kapcsol ki tanúsítványellenőrzést és nem tölt le semmit.
