# Töki Autó · Leltár – első változat

Külön alkalmazás a jegyzetelő mellett. Egy központi Windows 11 x64 géphez két telefon kapcsolódhat a bolti wifin. A program négy munkatárs nevét tárolja; közös bolti belépőkódot használ. A név választása nem személyre szóló hitelesítés. A programot a bolti helyi hálózaton használd, ne tedd nyilvánosan elérhetővé.

## Indítás Windows 11-en

1. Másold az egész `inventory` mappát egy állandó, írható helyre, pl. `C:\TokiLeltar`. A meglévő jegyzetelő és annak indítója változatlan.
2. Dupla kattintás: **Leltar-Inditas.cmd**. A kész ZIP mellékeli a futtatókörnyezetet. Ha ezek hiányoznak, az első indításhoz internet kell: a program hivatalos HTTPS-forrásból letölti a hordozható Node.js 24 LTS-t és a Caddy 2.10.2-t, Node esetén SHA256-, Caddy esetén SHA512-ellenőrzéssel. Ha nincs mellékelve `node_modules`, az npm a lockfile alapján telepít. Ne zárd be az ablakot.
3. Válaszd a gép bolti wifihez tartozó IPv4-címét. Több hálózati kártyánál az `ipconfig` segít. A routerben célszerű ehhez a géphez állandó DHCP-címet foglalni.
4. A Windows tűzfal kérdésénél a Caddy hozzáférését **csak a privát/bolti hálózaton** engedélyezd. Ha nincs kérdés, a rendszergazda engedélyezze a bejövő TCP 3443-at a helyi alhálózatról, privát hálózati profilban. A 3210-es belső portot nem kell megnyitni. A vendégwifi eszközelkülönítése megakadályozhatja a kapcsolódást.
5. A telefonon a kiírt **`https://GÉP-IP-CÍME:3443`** címet használd. A kamerához az alábbi egyszeri tanúsítványtelepítés szükséges.
6. Lépj be a saját neveddel és az indítóablakban megjelenő bolti kóddal. Visszatéréskor ugyanazt a nevet használd. A munkamenet 12 óra után és központi újraindításkor lejár.
7. A központi gép ne aludjon el leltározás közben. Leállítás: az indító ablakában Enter. A telefonnak nem kell mobilinternet, a központ első telepítése és a külső termékkeresés igényel internetet.

A Windows-indítószkript Linuxon készült; a Windowsos első indítást, tűzfalengedélyt és valódi iPhone/Android kamerát a boltban még ellenőrizni kell.

## Telefonos kamera: egyszeri HTTPS-bizalom

A helyi Caddy a saját bolti tanúsítványát készíti el. Az indító a **nyilvános gyökértanúsítványt** `Toki-Leltar-CA.crt` néven kimásolja. Ezt juttasd el a telefonokra például USB-n vagy a saját fájlmegosztásoddal. Csak a saját bolti gépeden létrejött fájlt telepítsd. A `data/https` mappát és az ott lévő privát kulcsokat ne oszd meg.

- **iPhone:** nyisd meg a tanúsítványt, majd Beállítások → Általános → VPN és eszközfelügyelet → letöltött profil telepítése. Ezután Általános → Infó → Tanúsítványbizalmi beállítások alatt engedélyezd a teljes bizalmat a bolti Caddy gyökértanúsítványhoz. Indítsd újra a Safarit, nyisd meg a HTTPS-címet, engedélyezd a kamerát.
- **Android:** Beállítások → Biztonság / Adatvédelem → További biztonsági beállítások → Titkosítás és hitelesítő adatok → Tanúsítvány telepítése → CA-tanúsítvány. A pontos menü készülékfüggő. Chrome-ban nyisd meg a HTTPS-címet és engedélyezd a kamerát.
- **Windows böngésző:** ha a Caddy automatikus bizalmi telepítése nem sikerült, a saját gyökértanúsítvány a jelenlegi felhasználó Megbízható legfelső szintű hitelesítésszolgáltatók tárolójába telepíthető.

Nem elég átkattintani a böngésző tanúsítványhibáján: a kamera ettől még tiltva maradhat. A TLS-ellenőrzést ne kapcsold ki. Más IP-cím esetén az indítót újra kell indítani; ugyanaz a helyi hitelesítésszolgáltató új szervertanúsítványt állít ki. A tanúsítványok és a telefonos használat helyszíni beállítása a kész telepítés része.

## Leltározás

- Indíts **új leltárt**. Egyszerre egy nyitott leltár van; a korábbiak a választóban megnyithatók és exportálhatók. A terméktár megmarad, az új számlálás nulla.
- **Kamera indítása**: minden elfogadott kód +1 darab. A folyamatosan képben tartott kód egyszer számít. Az újabb azonos darab előtt legalább kb. egy másodpercre vedd ki a kódot a képből. A hang és rezgés böngészőfüggő; mindig a sikerüzenet és a számláló az irányadó.
- Kézi bevitel vagy billentyűzetként működő USB/Bluetooth olvasó: kattints a vonalkódmezőbe, beolvasás után Enter. Itt minden beküldés szándékos +1.
- Ismeretlen kódnál megnyílik a termékfelvitel. A **Termék keresése az interneten** gomb a vonalkódra keres; a nevet, gyártót és cikkszámot ellenőrizd a csomagoláson vagy hiteles katalógusban. Mentéskor az első darabot is rögzíti. A kamera utána kézzel újraindítható.
- A FILTRON OP 612 / 5904608006127 olajszűrő a beküldött címke alapján szerepel a terméktárban; előre megszámolt darabot nem tartalmaz.
- A beszállítókhoz (Inter Cars, Bárdi, Unix stb.) nincs automatikus API-kapcsolat és nincs háttérben végzett adatkinyerés. Az általános keresés nem garantál találatot. Később szerződött adatszolgáltatás vagy ellenőrzött terméklista importja csatlakoztatható.
- A **visszavonás** csak a saját, még vissza nem vont beolvasásra vonatkozik. A másik telefon műveletei rövid időn belül megjelennek.
- Bizonytalan hálózati mentésnél ne számold újra: az **újrapróbálás** ugyanazzal az azonosítóval küldi újra a műveletet, újratöltés után is. Ehhez engedélyezni kell a böngésző helyi tárolását. Offline számlálás nincs. Függő műveletnél ne töröld a böngésző adatait és ne válts másik eszközre, amíg a mentést nem rendezted.
- Lezárás előtt mindkét kolléga fejezze be a számlálást és rendezze a függő kéréseit. A lezárt leltár nem módosítható. Az Excel-export UTF-8, pontosvesszős CSV. Excelben a vonalkódoszlopot szövegként importáld, hogy a kezdő nullák megmaradjanak.

## Mentés és helyreállítás

Minden változás atomikusan a `data/inventory.json` fájlba íródik. Az első változtatás előtti napi állapotról automatikus másolat készül a `data/backups` alatt. A teljes mentés gomb letölti az összes terméket, leltárt, munkatársat és műveletet. A bolti hozzáférési kódot nem tartalmazza. Naponta ments külön USB-re vagy másik biztonságos helyre is; az azonos gépen lévő másolat nem véd géphiba ellen.

Visszaállítás: állítsd le a központot, őrizd meg a jelenlegi adatfájlt külön néven, és a kiválasztott teljes JSON-mentést másold a `data/inventory.json` helyére. Indítsd újra, ellenőrizd a leltár nevét és darabszámait. Ne olvassz össze kézzel két mentést. A `data/access.json` a bolti kódot tartalmazza; ne küldd el másnak. A teljes `data` könyvtár a bolti gépen maradjon, ne kerüljön Gitbe vagy nyilvános csomagba.

Ez időszakos leltár, nem napi készletkezelő: bevételezés, értékesítés, pénzügyi értékelés és készletfoglalás még nincs.

## Fejlesztés Linuxon / macOS-en

Node.js 22.22.2+ vagy 24 LTS, npm. Használd a meglévő checkoutot, külön worktree nem szükséges.

```sh
cd inventory
npm ci --ignore-scripts
npm test
npm start
```

Az alapértelmezett szerver csak `127.0.0.1:3210` címen figyel; a localhost böngészőben kamerára is biztonságos eredet. Távoli telefonhoz megbízható HTTPS kell. Saját tanúsítvánnyal közvetlenül is indítható: `INVENTORY_TLS_CERT`, `INVENTORY_TLS_KEY`, `HOST`, `PORT`. Fordított HTTPS-proxy esetén `INVENTORY_HTTPS=1`, a Node továbbra is loopbacken figyeljen. `INVENTORY_DATA_DIR` külön adatkönyvtárat, `INVENTORY_ACCESS_CODE` külön kódot adhat meg. Egy adatkönyvtárhoz pontosan egy kiszolgálópéldány fusson.

A meglévő jegyzetelő ellenőrzése külön, a tároló gyökerében: `npm test`. Windows-csomagolása nem csomagolja magával a leltárt.

### Böngészőteszt

Fejlesztői függőségekkel (`npm ci --ignore-scripts`) és helyileg telepített Chrome/Chromium böngészővel: `npm run test:browser`. Linuxon alapértelmezés: `/usr/bin/chromium`; más rendszerben `CHROMIUM_PATH` adja meg a böngésző futtatható fájlját. Két izolált mobilméretű böngészővel ellenőrzi az együtt számlálást, termékfelvitelt, visszavonást, hálózati válasz elvesztése utáni újrapróbálást, lezárást, új leltárt és valódi EAN-13 képfelismerést. A hardveres kamerát ez nem helyettesíti.
