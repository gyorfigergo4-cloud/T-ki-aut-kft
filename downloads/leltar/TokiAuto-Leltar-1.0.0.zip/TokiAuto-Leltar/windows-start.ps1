# Windows 11, PowerShell 5.1. Local application; no user data is uploaded.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$tools = Join-Path $PSScriptRoot 'data\tools'
New-Item -ItemType Directory -Force -Path $tools | Out-Null
function Download-Verified($Url, $Target, $Expected, $Algorithm = 'SHA256') {
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Target
    if ((Get-FileHash -Algorithm $Algorithm $Target).Hash.ToLowerInvariant() -ne $Expected.ToLowerInvariant()) {
        Remove-Item $Target
        throw 'A letoltes ellenorzoosszege hibas. A telepites leallt.'
    }
}
# Use a portable Node 24 LTS runtime, checksum-verified from the official HTTPS source.
$nodeDir = Join-Path $tools 'node'
$node = Join-Path $nodeDir 'node.exe'
if (!(Test-Path $node)) {
    Write-Host 'Node.js LTS letoltese es ellenorzese...'
    $sums = (Invoke-WebRequest -UseBasicParsing 'https://nodejs.org/dist/latest-v24.x/SHASUMS256.txt').Content
    $match = [regex]::Match($sums, '(?m)^([a-f0-9]{64})\s+(node-v24\.[0-9]+\.[0-9]+-win-x64\.zip)\s*$')
    if (!$match.Success) { throw 'Nem talalhato a hivatalos Node.js Windows-csomag.' }
    $file = $match.Groups[2].Value
    $zip = Join-Path $tools $file
    Download-Verified "https://nodejs.org/dist/latest-v24.x/$file" $zip $match.Groups[1].Value
    Expand-Archive -Force $zip $tools
    Move-Item (Join-Path $tools ($file -replace '\.zip$', '')) $nodeDir
    Remove-Item $zip
}
$env:PATH = "$nodeDir;$env:PATH"
if (!(Test-Path 'node_modules\@zxing\browser\umd\zxing-browser.min.js')) {
    & (Join-Path $nodeDir 'npm.cmd') ci --ignore-scripts
    if ($LASTEXITCODE -ne 0) { throw 'A fuggosegek telepitese sikertelen.' }
}
$caddy = Join-Path $tools 'caddy.exe'
if (!(Test-Path $caddy)) {
    Write-Host 'A helyi HTTPS-kiszolgalo letoltese es ellenorzese...'
    $release = 'https://github.com/caddyserver/caddy/releases/download/v2.10.2'
    $checks = (Invoke-WebRequest -UseBasicParsing "$release/caddy_2.10.2_checksums.txt").Content
    $match = [regex]::Match($checks, '(?m)^([a-fA-F0-9]{128})\s+caddy_2\.10\.2_windows_amd64\.zip\s*$')
    if (!$match.Success) { throw 'Nem talalhato a Caddy SHA512 ellenorzoosszege.' }
    $zip = Join-Path $tools 'caddy.zip'
    Download-Verified "$release/caddy_2.10.2_windows_amd64.zip" $zip $match.Groups[1].Value SHA512
    Expand-Archive -Force $zip (Join-Path $tools 'caddy-unpack')
    Move-Item (Join-Path $tools 'caddy-unpack\caddy.exe') $caddy
    Remove-Item $zip
}
$ips = @(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.PrefixOrigin -ne 'WellKnown' } | Select-Object -ExpandProperty IPAddress)
Write-Host "A gep helyi cimei: $($ips -join ', ')"
$defaultIp = $ips | Select-Object -First 1
$ip = Read-Host "A bolti wifihez tartozo IPv4 cim (Enter: $defaultIp)"
if ([string]::IsNullOrWhiteSpace($ip)) { $ip = $defaultIp }
$parsed = $null
if (![Net.IPAddress]::TryParse($ip, [ref]$parsed) -or $parsed.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork -or $ips -notcontains $ip) { throw 'A gep egyik ervenyes helyi IPv4 cimet add meg.' }
$storage = (Join-Path $PSScriptRoot 'data\https') -replace '\\', '/'
$config = Join-Path $PSScriptRoot 'data\Caddyfile'
@"
{
    admin off
    auto_https disable_redirects
    storage file_system {
        root "$storage"
    }
}
https://${ip}:3443 {
    tls internal
    reverse_proxy 127.0.0.1:3210
}
"@ | Set-Content -Encoding ASCII $config
# The application stays loopback-only; Caddy handles the encrypted LAN connection.
$env:HOST = '127.0.0.1'
$env:PORT = '3210'
$env:INVENTORY_HTTPS = '1'
$appProcess = $null
$proxyProcess = $null
try {
    foreach ($port in @(3210, 3443)) {
        if (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue) { throw "A(z) $port port mar foglalt. Zarj be minden korabbi leltarinditot." }
    }
    $appProcess = Start-Process -FilePath $node -ArgumentList 'server.js' -WorkingDirectory $PSScriptRoot -NoNewWindow -PassThru
    $proxyProcess = Start-Process -FilePath $caddy -ArgumentList @('run', '--config', ('"' + $config + '"'), '--adapter', 'caddyfile') -NoNewWindow -PassThru
    $ready = $false
    for ($i = 0; $i -lt 30; $i++) {
        Start-Sleep -Milliseconds 500
        if ($appProcess.HasExited -or $proxyProcess.HasExited) { throw 'A kiszolgalo leallt. Olvasd el a fenti hibauzenetet.' }
        try { $response = Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:3210/'; if ($response.StatusCode -eq 200) { $ready = $true; break } } catch { }
    }
    if (!$ready) { throw 'A leltarkozpont nem indult el.' }
    $rootCert = Join-Path $PSScriptRoot 'data\https\pki\authorities\local\root.crt'
    for ($i = 0; $i -lt 20 -and !(Test-Path $rootCert); $i++) { Start-Sleep -Milliseconds 500 }
    if (!(Test-Path $rootCert)) { throw "A HTTPS tanusitvany nem keszult el. Ellenorizd a Caddy uzeneteit." }
    if (Test-Path $rootCert) {
        Copy-Item $rootCert (Join-Path $PSScriptRoot 'Toki-Leltar-CA.crt') -Force
        Write-Host 'A telefonra telepitendo nyilvanos tanusitvany: Toki-Leltar-CA.crt'
    }
    Write-Host "`nTELEFONON EZT NYISD MEG: https://${ip}:3443" -ForegroundColor Green
    Write-Host 'Elso hasznalat: TELEPITES.md - tanusitvany es Windows tuzfal. Nincs tanusitvany-ellenorzes kikapcsolas.'
    Write-Host 'A fenti bolti belepokoddal es a sajat neveddel jelentkezz be. Ezt az ablakot hagyd nyitva.'
    Read-Host 'Leallitas: Enter'
} finally {
    if ($proxyProcess -and !$proxyProcess.HasExited) { Stop-Process -Id $proxyProcess.Id }
    if ($appProcess -and !$appProcess.HasExited) { Stop-Process -Id $appProcess.Id }
}
