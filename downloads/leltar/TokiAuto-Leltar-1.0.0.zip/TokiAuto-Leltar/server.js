'use strict';
const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Store, Problem, atomic } = require('./store');
function createApp({ dir, code, secure = false } = {}) {
  const store = new Store(dir || path.join(__dirname, 'data'));
  const sessions = new Map(), attempts = new Map();
  const equal = (a, b) => { const x = crypto.createHash('sha256').update(a).digest(); const y = crypto.createHash('sha256').update(b).digest(); return crypto.timingSafeEqual(x, y); };
  const send = (res, status, value) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(value)); };
  const body = async req => { let raw = ''; for await (const chunk of req) { raw += chunk; if (Buffer.byteLength(raw) > 16384) throw new Problem(413, 'Túl nagy kérés.'); } try { const b = JSON.parse(raw); if (!b || typeof b !== 'object' || Array.isArray(b)) throw Error(); return b; } catch { throw new Problem(400, 'Hibás JSON-kérés.'); } };
  const cookie = req => /(?:^|;\s*)toki_session=([a-f0-9]{64})(?:;|$)/.exec(req.headers.cookie || '')?.[1];
  return { store, handler: async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'; form-action 'self'");
    try {
      const url = new URL(req.url, 'http://localhost');
      if (req.method === 'POST') {
        if (!/^application\/json(?:;|$)/i.test(req.headers['content-type'] || '')) throw new Problem(415, 'JSON-kérés szükséges.');
        if (req.headers['sec-fetch-site'] === 'cross-site') throw new Problem(403, 'Idegen oldalról indított kérés.');
        if (req.headers.origin && req.headers.origin !== `${secure ? 'https' : 'http'}://${req.headers.host}`) throw new Problem(403, 'Eltérő eredetű kérés.');
      }
      if (url.pathname === '/api/login' && req.method === 'POST') {
        const key = req.socket.remoteAddress, now = Date.now();
        const attempt = attempts.get(key) || { count: 0, since: now };
        if (now - attempt.since > 60000) { attempt.count = 0; attempt.since = now; }
        attempts.set(key, attempt);
        if (++attempt.count > 15) throw new Problem(429, 'Túl sok próbálkozás. Várj egy percet.');
        const b = await body(req);
        if (typeof b.code !== 'string' || !equal(b.code, code || '')) throw new Problem(401, 'Hibás bolti belépőkód.');
        const user = store.user(b.name); const token = crypto.randomBytes(32).toString('hex');
        for (const [key, s] of sessions) if (s.until < now) sessions.delete(key);
        sessions.set(token, { user, until: now + 12 * 60 * 60 * 1000 }); attempts.delete(key);
        res.setHeader('Set-Cookie', `toki_session=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200${secure ? '; Secure' : ''}`);
        return send(res, 200, { user });
      }
      if (url.pathname.startsWith('/api/')) {
        const session = sessions.get(cookie(req));
        if (!session || session.until < Date.now()) throw new Problem(401, 'Jelentkezz be a bolti kóddal.');
        if (req.method === 'GET' && url.pathname === '/api/state') {
          if (url.searchParams.get('since') === String(store.data.revision)) return send(res, 200, { unchanged: true });
          return send(res, 200, { ...store.snapshot(), me: session.user });
        }
        if (req.method === 'POST' && url.pathname === '/api/action') return send(res, 200, store.mutate(session.user, await body(req)));
        if (req.method === 'POST' && url.pathname === '/api/logout') { sessions.delete(cookie(req)); res.setHeader('Set-Cookie', 'toki_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'); return send(res, 200, { ok: true }); }
        if (req.method === 'GET' && url.pathname === '/api/export') {
          const rows = store.rows(url.searchParams.get('id'));
          const cell = v => '"' + String(v).replace(/^[=+@\-\t\r]/, "'$&").replaceAll('"', '""') + '"';
          const csv = '\uFEFF' + [['Név', 'Gyártó', 'Cikkszám', 'Vonalkód', 'Darabszám'], ...rows.map(p => [p.name, p.brand, p.partNumber, p.barcode, p.quantity])].map(r => r.map(cell).join(';')).join('\r\n');
          res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="toki-leltar.csv"', 'Cache-Control': 'no-store' }); return res.end(csv);
        }
        if (req.method === 'GET' && url.pathname === '/api/backup') { res.setHeader('Content-Disposition', 'attachment; filename="toki-leltar-mentes.json"'); return send(res, 200, store.data); }
        throw new Problem(404, 'Nincs ilyen művelet.');
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new Problem(405, 'Nem támogatott kérés.');
      const files = { '/': ['public/index.html', 'text/html; charset=utf-8'], '/app.js': ['public/app.js', 'text/javascript'], '/scanner.js': ['public/scanner.js', 'text/javascript'], '/style.css': ['public/style.css', 'text/css'], '/icon.svg': ['public/icon.svg', 'image/svg+xml'], '/manifest.webmanifest': ['public/manifest.webmanifest', 'application/manifest+json'], '/vendor/zxing.js': ['node_modules/@zxing/browser/umd/zxing-browser.min.js', 'text/javascript'] };
      const file = files[url.pathname]; if (!file) throw new Problem(404, 'Nem található.');
      const content = fs.readFileSync(path.join(__dirname, file[0])); res.writeHead(200, { 'Content-Type': file[1], 'Cache-Control': 'no-cache' }); res.end(req.method === 'HEAD' ? undefined : content);
    } catch (err) { if (!err.status) console.error(err); if (!res.headersSent) send(res, err.status || 500, { error: err.status ? err.message : 'A mentés nem sikerült. Ne számold újra; próbáld újra ugyanazt a kérést.' }); else res.destroy(); }
  } };
}
if (require.main === module) {
  const dir = process.env.INVENTORY_DATA_DIR || path.join(__dirname, 'data'); fs.mkdirSync(dir, { recursive: true });
  const configPath = path.join(dir, 'access.json');
  if (!fs.existsSync(configPath)) atomic(configPath, { code: crypto.randomBytes(6).toString('hex') });
  const code = process.env.INVENTORY_ACCESS_CODE || JSON.parse(fs.readFileSync(configPath, 'utf8')).code;
  const tls = process.env.INVENTORY_TLS_CERT && process.env.INVENTORY_TLS_KEY;
  const secure = Boolean(tls || process.env.INVENTORY_HTTPS === '1');
  const app = createApp({ dir, code, secure });
  const server = tls ? https.createServer({ cert: fs.readFileSync(process.env.INVENTORY_TLS_CERT), key: fs.readFileSync(process.env.INVENTORY_TLS_KEY) }, app.handler) : http.createServer(app.handler);
  const port = Number(process.env.PORT || 3210), host = process.env.HOST || '127.0.0.1';
  server.requestTimeout = 15000;
  server.listen(port, host, () => { console.log(`Töki Autó leltár: ${tls ? 'https' : 'http'}://${host}:${port}`); console.log(`Bolti belépőkód: ${code}\nAdatkönyvtár: ${path.resolve(dir)}\nTelefonos kamerához megbízható HTTPS szükséges. A bezárás leállítja a központot.`); });
}
module.exports = { createApp };
