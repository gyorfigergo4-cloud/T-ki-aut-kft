/* ZXing runs locally, including on Safari without BarcodeDetector. */
(function (root) {
  class ScanGate {
    constructor() { this.last = null; this.lastSeen = 0; this.locked = false; this.absentFrames = 0; }
    observe(code, now = Date.now()) {
      if (!code) { this.absentFrames++; return false; }
      const accept = !this.locked && (this.last === null || this.last !== code || (this.absentFrames >= 3 && now - this.lastSeen >= 900));
      this.lastSeen = now; this.absentFrames = 0;
      if (accept) this.last = code;
      return accept;
    }
  }
  root.ScanGate = ScanGate;
  if (typeof module !== 'undefined') module.exports = { ScanGate };
})(typeof window !== 'undefined' ? window : globalThis);
