'use strict';
const $ = id => document.getElementById(id);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const normalize = v => String(v).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
let state = null, selected = null, tab = 'scan', busy = false, pending = null, productId = null, countAfterProduct = null, lastOwn = null;
let controls = null, reader = null, starting = false, torch = false, toastTimer, cameraGeneration = 0;
const gate = new ScanGate();
let soundContext;
function unlockSound() {
  try { soundContext ||= new (window.AudioContext || window.webkitAudioContext)(); soundContext.resume().catch(() => {}); } catch { /* audio is optional */ }
}
try { pending = JSON.parse(localStorage.getItem('toki-pending') || 'null'); } catch { /* browser storage can be restricted */ }
function savePending(value) {
  // Never send a mutation unless its retry ID is safely retained across reloads.
  try { if (value) localStorage.setItem('toki-pending', JSON.stringify(value)); else localStorage.removeItem('toki-pending'); }
  catch { if (value) throw Error('A böngésző nem engedi a helyi tárolást. Engedélyezd a webhelyadatok mentését a biztonságos számláláshoz.'); }
  pending = value;
}
function toast(message, error = false) { clearTimeout(toastTimer); $('message').textContent = message; $('message').classList.toggle('error', error); $('message').hidden = false; toastTimer = setTimeout(() => $('message').hidden = true, error ? 8000 : 3500); }
async function api(url, data) {
  const response = await fetch(url, { method: data ? 'POST' : 'GET', headers: data ? { 'Content-Type': 'application/json' } : {}, body: data ? JSON.stringify(data) : undefined, signal: AbortSignal.timeout(12000) });
  const value = await response.json();
  if (!response.ok) { const error = Error(value.error || 'A kérés sikertelen.'); error.status = response.status; throw error; }
  return value;
}
function connected(ok) { $('connection').textContent = ok ? 'Kapcsolódva' : 'Nincs kapcsolat'; $('connection').className = 'connection ' + (ok ? 'online' : 'offline'); }
function loginView() { stopCamera(); $('workspace').hidden = true; $('login').hidden = false; $('logout').hidden = true; connected(false); }
function inventory() { return state?.inventories.find(i => i.id === selected); }
function active() { return inventory() && !inventory().closedAt; }
function events() { return state?.events.filter(e => e.inventoryId === selected) || []; }
function rows() {
  const result = new Map();
  for (const e of events()) { const row = result.get(e.productId) || { ...e.product, quantity: 0 }; row.quantity += e.delta; result.set(e.productId, row); }
  return [...result.values()].filter(p => p.quantity > 0).sort((a, b) => a.name.localeCompare(b.name, 'hu'));
}
async function refresh() {
  try {
    const next = await api('/api/state' + (state ? '?since=' + state.revision : ''));
    if (next.unchanged) { connected(true); return; }
    if (!state || next.revision >= state.revision) state = next;
    if (!selected || !state.inventories.some(i => i.id === selected)) selected = state.inventories.find(i => !i.closedAt)?.id || state.inventories.at(-1)?.id || null;
    $('login').hidden = true; $('workspace').hidden = false; $('logout').hidden = false; connected(true); render();
  } catch (error) { connected(false); if (error.status === 401) loginView(); throw error; }
}
function render() {
  if (!state) return;
  const current = inventory(), list = rows(), allEvents = events();
  $('greeting').textContent = `Szia, ${state.me.name}! A beolvasásaid a közös listába kerülnek.`;
  const options = state.inventories.map(i => ({ value: i.id, label: `${i.name}${i.closedAt ? ' · lezárt' : ' · folyamatban'}` }));
  if (!options.length) options.push({ value: '', label: 'Még nincs leltár — indíts egyet!' });
  $('inventory-select').replaceChildren(...options.map(i => new Option(i.label, i.value, false, i.value === selected)));
  $('inventory-status').textContent = current ? (current.closedAt ? 'Lezárt leltár' : '● Folyamatban') : 'Nincs leltár';
  $('inventory-status').classList.toggle('green', Boolean(active()));
  $('open-inventory').disabled = busy || Boolean(pending) || state.inventories.some(i => !i.closedAt);
  $('close-inventory').hidden = !active(); $('close-inventory').disabled = busy || Boolean(pending);
  $('start-camera').disabled = !active() || busy || Boolean(pending) || starting;
  $('manual-form').querySelector('button').disabled = !active() || busy || Boolean(pending);
  $('barcode').disabled = !active() || busy || Boolean(pending);
  if (!active()) stopCamera();
  $('total').textContent = list.reduce((sum, p) => sum + p.quantity, 0); $('unique').textContent = list.length;
  const own = allEvents.filter(e => e.userId === state.me.id && e.delta === 1 && !allEvents.some(u => u.undoOf === e.id));
  lastOwn = own.at(-1);
  $('last-scan').innerHTML = lastOwn ? `<span class="eyebrow">UTOLSÓ SAJÁT BEOLVASÁS</span><h2>${esc(lastOwn.product.brand)} ${esc(lastOwn.product.name)}</h2><p class="muted">${esc(lastOwn.product.partNumber)} · ${esc(lastOwn.product.barcode)}</p><span class="quantity">${list.find(p => p.id === lastOwn.productId)?.quantity || 0} <small>db a leltárban</small></span>${active() ? '<br><button id="undo" class="quiet">↶ Utolsó csippantás visszavonása</button>' : ''}` : '<span class="eyebrow">UTOLSÓ SAJÁT BEOLVASÁS</span><h2>Még nincs saját beolvasás</h2><p class="muted">A legutóbbi saját tételedet itt vonhatod vissza.</p>';
  if ($('undo')) { $('undo').disabled = busy || Boolean(pending); $('undo').onclick = () => runJob([{ action: 'undo', inventoryId: selected, eventId: lastOwn.id }], 'undo'); }
  $('activity-count').textContent = `${allEvents.length} művelet`;
  $('activity').innerHTML = allEvents.slice(-6).reverse().map(e => `<li><span class="delta">${e.delta > 0 ? '+1' : '−1'}</span><div><strong>${esc(e.product.brand)} ${esc(e.product.partNumber)}</strong><small>${esc(state.users.find(u => u.id === e.userId)?.name || '')}${e.undoOf ? ' · visszavonás' : ''}</small></div><time>${new Date(e.at).toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' })}</time></li>`).join('') || '<li class="muted">Az első beolvasás itt fog megjelenni.</li>';
  const matches = (p, query) => normalize(`${p.brand} ${p.name} ${p.partNumber} ${p.barcode}`).includes(normalize(query));
  const filtered = list.filter(p => matches(p, $('list-search').value));
  $('inventory-rows').innerHTML = filtered.map(p => `<tr><td><strong>${esc(p.name)}</strong><small>${esc(p.brand)}</small></td><td>${esc(p.partNumber)}</td><td>${esc(p.barcode)}</td><td class="number">${p.quantity} <small>db</small></td></tr>`).join('');
  $('list-empty').hidden = filtered.length > 0; $('list-empty').textContent = list.length ? 'Nincs találat.' : 'Még nincs megszámolt termék ebben a leltárban.';
  const catalog = state.products.filter(p => matches(p, $('catalog-search').value)).sort((a, b) => a.name.localeCompare(b.name, 'hu'));
  $('catalog-rows').innerHTML = catalog.map(p => `<tr><td><strong>${esc(p.name)}</strong><small>${esc(p.brand)}</small></td><td>${esc(p.partNumber)}</td><td>${esc(p.barcode)}</td><td><button class="quiet edit-product" data-id="${esc(p.id)}">Szerkesztés</button></td></tr>`).join('');
  document.querySelectorAll('.edit-product').forEach(button => { button.disabled = busy || Boolean(pending); button.onclick = () => openProduct(state.products.find(p => p.id === button.dataset.id)); });
  $('catalog-empty').hidden = catalog.length > 0;
  $('export').hidden = !current; $('export').href = current ? '/api/export?id=' + encodeURIComponent(current.id) : '#';
  $('add-product').disabled = busy || Boolean(pending);
  $('retry-panel').hidden = !pending || busy;
  gate.locked = busy || Boolean(pending) || !active() || $('product-dialog').open;
}
async function runJob(steps, kind) {
  if (busy || pending) return;
  try {
    savePending({ userId: state.me.id, kind, steps: steps.map(step => ({ ...step, requestId: crypto.randomUUID ? crypto.randomUUID() : Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, '0')).join('') })) });
    await retryJob();
  } catch (e) { toast(e.message, true); }
}
async function retryJob() {
  if (busy || !pending) return;
  if (pending.userId !== state.me.id) return toast('Ez a függő művelet másik munkatárshoz tartozik. Lépj be az eredeti névvel.', true);
  busy = true; render(); const kind = pending.kind;
  try {
    while (pending.steps.length) {
      await api('/api/action', pending.steps[0]);
      savePending({ ...pending, steps: pending.steps.slice(1) });
    }
    savePending(null);
    for (const id of ['product-dialog', 'new-dialog', 'close-dialog']) $(id).close();
    countAfterProduct = null;
    if (kind === 'scan' || kind === 'product-scan') { beep(); toast('Rögzítve · +1 darab'); $('barcode').value = ''; }
    else toast(kind === 'undo' ? 'Beolvasás visszavonva · −1 darab' : 'Sikeresen mentve.');
    try { await refresh(); } catch { toast('A művelet mentve. A lista frissítése a kapcsolat helyreállásakor folytatódik.', true); }
  } catch (e) {
    if (e.status && e.status >= 400 && e.status < 500 && e.status !== 401 && e.status !== 429) {
      savePending(null);
      const errorId = $('product-dialog').open ? 'product-error' : $('new-dialog').open ? 'new-error' : 'close-error';
      $(errorId).textContent = e.message; toast(e.message, true);
      try { await refresh(); } catch { /* retain current view */ }
    } else {
      stopCamera(); for (const id of ['product-dialog', 'new-dialog', 'close-dialog']) $(id).close(); toast(e.status === 401 ? 'A munkamenet lejárt. Lépj be újra ugyanazzal a névvel; a függő művelet megmarad.' : 'A mentés eredménye bizonytalan. Használd az újrapróbálás gombot.', true);
      if (e.status === 401) loginView();
    }
  } finally { busy = false; if (state) render(); }
}
function beep() {
  try { unlockSound(); const ctx = soundContext; const osc = ctx.createOscillator(), gain = ctx.createGain(); osc.connect(gain); gain.connect(ctx.destination); gain.gain.value = .08; osc.frequency.value = 1250; osc.start(); osc.stop(ctx.currentTime + .12); osc.onended = () => { osc.disconnect(); gain.disconnect(); }; } catch { /* sound unavailable */ }
  navigator.vibrate?.(70);
}
async function scan(raw) {
  if (busy || pending || !active() || $('product-dialog').open) return;
  const code = raw.trim(); if (!code) return;
  const product = state.products.find(p => p.barcode === code);
  if (!product) {
    stopCamera(); countAfterProduct = { barcode: code, inventoryId: selected };
    openProduct({ barcode: code }, true); return;
  }
  await runJob([{ action: 'scan', inventoryId: selected, barcode: code }], 'scan');
}
function openProduct(product = {}, forScan = false) {
  productId = product.id || null; if (!forScan) countAfterProduct = null;
  $('product-form').reset(); $('product-error').textContent = '';
  for (const key of ['barcode', 'name', 'brand', 'partNumber']) $('product-form').elements[key].value = product[key] || '';
  $('product-form').elements.barcode.readOnly = Boolean(forScan || productId);
  $('product-title').textContent = productId ? 'Termék szerkesztése' : 'Új vonalkód · termék felvétele';
  $('save-product').textContent = forScan ? 'Termék mentése és +1 darab' : 'Termék mentése';
  updateLookup(); $('product-dialog').showModal(); gate.locked = true;
}
function updateLookup() { const code = $('product-form').elements.barcode.value.trim(); $('lookup').href = 'https://www.google.com/search?q=' + encodeURIComponent(`"${code}" alkatrész cikkszám`); }
async function startCamera() {
  if (controls || starting || busy || pending || !active()) return;
  if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) return toast('A kamerához megbízható HTTPS-cím szükséges. A bolti telepítési útmutató szerint csatlakozz; addig a kézi bevitel használható.', true);
  starting = true; const generation = ++cameraGeneration; $('start-camera').disabled = true;
  try {
    if (!window.ZXingBrowser) throw Error('A vonalkódolvasó nem töltődött be. Frissítsd az oldalt.');
    reader = new ZXingBrowser.BrowserMultiFormatReader(undefined, { delayBetweenScanAttempts: 150, delayBetweenScanSuccess: 150 });
    const next = await reader.decodeFromConstraints({ audio: false, video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } } }, $('video'), (result, error) => {
      if (generation !== cameraGeneration) return;
      const code = result?.getText(); if (gate.observe(code)) scan(code);
    });
    if (generation !== cameraGeneration) { next.stop(); return; }
    controls = next; $('camera-placeholder').hidden = true; $('start-camera').hidden = true; $('stop-camera').hidden = false;
    $('torch').hidden = !controls.switchTorch;
    $('scanner-hint').textContent = 'Minden elfogadott csippantás +1 darab. Vedd ki a kódot a képből a következő darab előtt.';
  } catch (e) { if (generation === cameraGeneration) { stopCamera(); toast(e.name === 'NotAllowedError' ? 'Engedélyezd a kamera használatát a böngészőben.' : 'A kamera nem indult: ' + e.message, true); } }
  finally { starting = false; render(); }
}
function stopCamera() {
  cameraGeneration++; controls?.stop(); controls = null; starting = false; torch = false;
  const stream = $('video').srcObject; stream?.getTracks().forEach(t => t.stop()); $('video').srcObject = null;
  $('camera-placeholder').hidden = false; $('start-camera').hidden = false; $('stop-camera').hidden = true; $('torch').hidden = true;
}
$('login-form').onsubmit = async e => {
  e.preventDefault(); const button = e.target.querySelector('button'); button.disabled = true;
  try { await api('/api/login', Object.fromEntries(new FormData(e.target))); state = null; await refresh(); $('login-form').elements.code.value = ''; }
  catch (err) { toast(err.message, true); } finally { button.disabled = false; }
};
$('logout').onclick = async () => { stopCamera(); try { await api('/api/logout', {}); state = null; loginView(); } catch { toast('A kilépés nem sikerült. Próbáld újra.', true); } };
$('manual-form').onsubmit = e => { e.preventDefault(); unlockSound(); scan($('barcode').value); };
$('start-camera').onclick = () => { unlockSound(); startCamera(); }; $('stop-camera').onclick = stopCamera;
$('torch').onclick = async () => { try { torch = !torch; await controls.switchTorch(torch); $('torch').textContent = torch ? 'Vaku ki' : 'Vaku'; } catch { toast('Ezen a telefonon a vaku nem kapcsolható.', true); } };
$('retry').onclick = retryJob;
$('product-form').elements.barcode.oninput = updateLookup;
$('product-form').onsubmit = e => {
  e.preventDefault(); $('product-error').textContent = '';
  const steps = [{ ...Object.fromEntries(new FormData(e.target)), action: 'product', ...(productId ? { productId } : {}) }];
  if (countAfterProduct) steps.push({ action: 'scan', ...countAfterProduct });
  runJob(steps, countAfterProduct ? 'product-scan' : 'product');
};
$('add-product').onclick = () => openProduct();
$('open-inventory').onclick = () => { $('new-form').elements.name.value = new Date().toLocaleDateString('hu-HU') + ' leltár'; $('new-error').textContent = ''; $('new-dialog').showModal(); };
$('new-form').onsubmit = e => { e.preventDefault(); selected = null; runJob([{ action: 'open', name: e.target.elements.name.value }], 'open'); };
$('close-inventory').onclick = () => { stopCamera(); $('close-error').textContent = ''; $('close-dialog').showModal(); };
$('close-form').onsubmit = e => { e.preventDefault(); runJob([{ action: 'close', inventoryId: selected }], 'close'); };
$('inventory-select').onchange = e => { stopCamera(); selected = e.target.value; render(); };
for (const id of ['list-search', 'catalog-search']) $(id).oninput = render;
document.querySelectorAll('[data-tab]').forEach(button => button.onclick = () => {
  tab = button.dataset.tab; if (tab !== 'scan') stopCamera();
  document.querySelectorAll('[data-tab]').forEach(b => b.setAttribute('aria-selected', b.dataset.tab === tab));
  for (const name of ['scan', 'list', 'catalog']) $('tab-' + name).hidden = name !== tab;
});
document.querySelectorAll('[data-close]').forEach(button => button.onclick = () => { if (busy || pending) return toast('Előbb rendezd a függő mentést.', true); $(button.dataset.close).close(); countAfterProduct = null; render(); });
for (const dialog of document.querySelectorAll('dialog')) dialog.addEventListener('cancel', e => { if (busy || pending) e.preventDefault(); else { countAfterProduct = null; setTimeout(render, 0); } });
document.addEventListener('visibilitychange', () => { if (document.hidden) stopCamera(); else refresh().catch(() => {}); });
window.addEventListener('offline', () => { connected(false); stopCamera(); });
window.addEventListener('online', () => refresh().catch(() => {}));
refresh().catch(() => {});
setInterval(() => { if (!document.hidden && state && !busy) refresh().catch(() => {}); }, 1800);
