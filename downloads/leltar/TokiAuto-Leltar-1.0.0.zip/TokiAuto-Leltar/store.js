'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID, createHash } = require('node:crypto');
class Problem extends Error { constructor(status, message) { super(message); this.status = status; } }
const fail = (condition, message, status = 400) => { if (condition) throw new Problem(status, message); };
const text = (value, label, max = 160) => { fail(typeof value !== 'string' || !value.trim() || value.trim().length > max, `${label}: kötelező, legfeljebb ${max} karakter.`); return value.trim(); };
function barcode(value) { const code = text(value, 'Vonalkód', 80); fail(!/^[A-Za-z0-9 ._+\-/]+$/.test(code), 'Nem támogatott vonalkód.'); return code; }
function atomic(file, value) {
  const temp = file + '.tmp';
  const fd = fs.openSync(temp, 'w', 0o600);
  try { fs.writeFileSync(fd, JSON.stringify(value, null, 2)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  fs.renameSync(temp, file);
}
class Store {
  constructor(dir) {
    this.dir = dir; fs.mkdirSync(dir, { recursive: true }); this.file = path.join(dir, 'inventory.json');
    if (fs.existsSync(this.file)) {
      this.data = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      fail(this.data.version !== 1 || !Array.isArray(this.data.products) || !Array.isArray(this.data.events) || !Array.isArray(this.data.inventories) || !Array.isArray(this.data.users) || !Array.isArray(this.data.requests), 'Az adatfájl nem támogatott vagy sérült; állíts vissza biztonsági mentést.', 500);
      this.backup();
    } else {
      this.data = { version: 1, revision: 0, users: [], products: [{ id: randomUUID(), barcode: '5904608006127', name: 'Olajszűrő', brand: 'FILTRON', partNumber: 'OP 612' }], inventories: [], events: [], requests: [] };
      atomic(this.file, this.data);
    }
  }
  backup() {
    const dir = path.join(this.dir, 'backups'); fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `${new Date().toISOString().slice(0, 10)}.json`);
    if (!fs.existsSync(file)) fs.copyFileSync(this.file, file, fs.constants.COPYFILE_EXCL);
  }
  commit(next) { this.backup(); next.revision++; atomic(this.file, next); this.data = next; }
  user(name) {
    name = text(name, 'Név', 60);
    const existing = this.data.users.find(u => u.name.toLocaleLowerCase('hu') === name.toLocaleLowerCase('hu'));
    if (existing) return existing;
    fail(this.data.users.length >= 4, 'Már négy munkatárs van felvéve. Válaszd ki a saját nevedet.', 409);
    const next = structuredClone(this.data), user = { id: randomUUID(), name }; next.users.push(user); this.commit(next); return user;
  }
  mutate(user, body) {
    const key = text(body.requestId, 'Kérésazonosító', 100);
    const fingerprint = createHash('sha256').update(JSON.stringify({ ...body, requestId: undefined })).digest('hex');
    const previous = this.data.requests.find(r => r.id === key && r.userId === user.id);
    if (previous) { fail(previous.fingerprint !== fingerprint, 'A kérésazonosító más művelethez tartozik.', 409); return previous.result; }
    const next = structuredClone(this.data); let result;
    const current = () => {
      const inv = next.inventories.find(i => i.id === body.inventoryId);
      fail(!inv || inv.closedAt, 'A leltár nem nyitott. Frissítsd a listát.', 409); return inv;
    };
    if (body.action === 'product') {
      const fields = { barcode: barcode(body.barcode), name: text(body.name, 'Terméknév'), brand: typeof body.brand === 'string' ? body.brand.trim().slice(0, 100) : '', partNumber: text(body.partNumber, 'Cikkszám', 100) };
      fail(next.products.some(p => p.barcode === fields.barcode && p.id !== body.productId), 'Ezt a vonalkódot már felvették. Olvasd be újra.', 409);
      if (body.productId) { result = next.products.find(p => p.id === body.productId); fail(!result, 'A termék nem található.', 404); Object.assign(result, fields); }
      else { result = { id: randomUUID(), ...fields }; next.products.push(result); }
    } else if (body.action === 'open') {
      fail(next.inventories.some(i => !i.closedAt), 'Már van nyitott leltár.', 409);
      result = { id: randomUUID(), name: text(body.name, 'Leltár neve', 100), openedAt: new Date().toISOString(), openedBy: user.id, closedAt: null }; next.inventories.push(result);
    } else if (body.action === 'close') {
      result = current(); result.closedAt = new Date().toISOString(); result.closedBy = user.id;
    } else if (body.action === 'scan') {
      current(); const product = next.products.find(p => p.barcode === barcode(body.barcode));
      fail(!product, 'Ismeretlen termék. Először vedd fel a terméktárba.', 404);
      result = { id: randomUUID(), inventoryId: body.inventoryId, productId: product.id, product: structuredClone(product), userId: user.id, delta: 1, at: new Date().toISOString() }; next.events.push(result);
    } else if (body.action === 'undo') {
      current(); const event = next.events.find(e => e.id === body.eventId && e.inventoryId === body.inventoryId && e.delta === 1 && e.userId === user.id);
      fail(!event, 'Csak a saját beolvasásodat vonhatod vissza.', 409);
      fail(next.events.some(e => e.undoOf === event.id), 'Ezt a beolvasást már visszavontad.', 409);
      result = { id: randomUUID(), inventoryId: event.inventoryId, productId: event.productId, product: event.product, userId: user.id, delta: -1, undoOf: event.id, at: new Date().toISOString() }; next.events.push(result);
    } else throw new Problem(400, 'Ismeretlen művelet.');
    // Keep request IDs for the complete audit history, so a delayed retry never counts twice.
    next.requests.push({ id: key, userId: user.id, fingerprint, result: structuredClone(result) });
    this.commit(next); return result;
  }
  snapshot() {
    return { revision: this.data.revision, users: this.data.users, products: this.data.products, inventories: this.data.inventories, events: this.data.events };
  }
  rows(id) {
    fail(!this.data.inventories.some(i => i.id === id), 'Ismeretlen leltár.', 404);
    const rows = new Map();
    for (const e of this.data.events.filter(e => e.inventoryId === id)) {
      const row = rows.get(e.productId) || { ...e.product, quantity: 0 }; row.quantity += e.delta; rows.set(e.productId, row);
    }
    return [...rows.values()].filter(r => r.quantity > 0).sort((a, b) => a.name.localeCompare(b.name, 'hu'));
  }
}
module.exports = { Store, Problem, atomic };
