'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { Store } = require('../store');
const { createApp } = require('../server');
const { ScanGate } = require('../public/scanner');
const { randomUUID } = require('node:crypto');
function temp(t) { const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'toki-inventory-')); t.after(() => fs.rmSync(dir, { recursive: true, force: true })); return dir; }
function action(s, u, b) { return s.mutate(u, { requestId: randomUUID(), ...b }); }
test('two colleagues, durable retry, own undo, closing and historical snapshots', t => {
 const dir = temp(t); let s = new Store(dir); const a = s.user('Anna'), b = s.user('Béla');
 const inv = action(s,a,{ action:'open',name:'Első' });
 const scan = {requestId:randomUUID(),action:'scan',barcode:'5904608006127',inventoryId:inv.id};
 const event = s.mutate(a,scan); s.mutate(a,scan); action(s,b,{...scan,requestId:randomUUID()});
 assert.equal(s.rows(inv.id)[0].quantity,2);
 assert.throws(()=>s.mutate(a,{...scan,barcode:'OTHER'}),/más művelet/);
 s=new Store(dir); s.mutate(a,scan); assert.equal(s.rows(inv.id)[0].quantity,2);
 assert.throws(()=>action(s,b,{action:'undo',inventoryId:inv.id,eventId:event.id}),/saját/);
 action(s,a,{action:'undo',inventoryId:inv.id,eventId:event.id});
 assert.throws(()=>action(s,a,{action:'undo',inventoryId:inv.id,eventId:event.id}),/már visszavontad/);
 assert.equal(s.rows(inv.id)[0].quantity,1);
 assert.throws(()=>action(s,a,{action:'open',name:'Másik'}),/nyitott/);
 action(s,a,{action:'close',inventoryId:inv.id});
 assert.throws(()=>action(s,a,{...scan,requestId:randomUUID()}),/nem nyitott/);
 const second=action(s,a,{action:'open',name:'Második'});assert.deepEqual(s.rows(second.id),[]);
 action(s,a,{action:'product',productId:s.data.products[0].id,barcode:scan.barcode,name:'Új név',brand:'FILTRON',partNumber:'OP 612'});
 assert.equal(s.rows(inv.id)[0].name,'Olajszűrő');assert.equal(s.data.products.length,1);
 assert.ok(fs.readdirSync(path.join(dir,'backups')).length);
});
test('unknown codes, duplicate products and four-person limit',t=>{
 const s=new Store(temp(t)),a=s.user('Anna');assert.equal(s.user('anna').id,a.id);
 const inv=action(s,a,{action:'open',name:'Leltár'});
 assert.throws(()=>action(s,a,{action:'scan',inventoryId:inv.id,barcode:'UNKNOWN'}),/Ismeretlen/);
 action(s,a,{action:'product',barcode:'UNKNOWN',name:'Fékbetét',brand:'Márka',partNumber:'ABC-123'});
 assert.throws(()=>action(s,a,{action:'product',barcode:'UNKNOWN',name:'Más',partNumber:'456'}),/már felvették/);
 action(s,a,{action:'scan',barcode:'UNKNOWN',inventoryId:inv.id});assert.equal(s.rows(inv.id)[0].quantity,1);
 ['Béla','Cili','Dani'].forEach(n=>s.user(n));assert.throws(()=>s.user('Ötödik'),/négy/);
});
test('held barcode, jitter and busy operations never count repeatedly',()=>{
 const g=new ScanGate();assert.equal(g.observe('A',1000),true);assert.equal(g.observe('A',2500),false);
 [2600,2700,2800].forEach(t=>g.observe(null,t));assert.equal(g.observe('A',2900),false);
 for(let i=0;i<8;i++)g.observe(null,3000+i*150);assert.equal(g.observe('A',4300),true);
 g.locked=true;assert.equal(g.observe('B',4400),false);g.locked=false;assert.equal(g.observe('B',4600),true);
});
test('HTTP two-phone concurrency, retry, export, authentication and static assets',async t=>{
 const app=createApp({dir:temp(t),code:'test-code'}),server=http.createServer(app.handler);
 await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>server.close(r)));
 const base=`http://127.0.0.1:${server.address().port}`;
 const post=(url,data,cookie='',extra={})=>fetch(base+url,{method:'POST',headers:{'Content-Type':'application/json',Cookie:cookie,...extra},body:JSON.stringify(data)});
 assert.equal((await fetch(base+'/api/state')).status,401);
 assert.equal((await post('/api/login',{name:'Anna',code:'wrong'})).status,401);
 const la=await post('/api/login',{name:'Anna',code:'test-code'}),ca=la.headers.get('set-cookie').split(';')[0];
 const lb=await post('/api/login',{name:'Béla',code:'test-code'}),cb=lb.headers.get('set-cookie').split(';')[0];
 assert.equal((await post('/api/action',{},ca,{Origin:'https://evil.example'})).status,403);
 const inv=await(await post('/api/action',{requestId:randomUUID(),action:'open',name:'Közös'},ca)).json();
 const scans=Array.from({length:20},(_,i)=>({requestId:randomUUID(),action:'scan',barcode:'5904608006127',inventoryId:inv.id,cookie:i%2?ca:cb}));
 const results=await Promise.all(scans.map(({cookie,...body})=>post('/api/action',body,cookie)));assert.ok(results.every(r=>r.status===200));
 const {cookie,...body}=scans[0];assert.equal((await post('/api/action',body,cookie)).status,200);
 const csv=await(await fetch(base+'/api/export?id='+inv.id,{headers:{Cookie:ca}})).text();assert.match(csv,/"20"/);
 const snapshot=await(await fetch(base+'/api/state',{headers:{Cookie:cb}})).json();assert.equal(snapshot.events.length,20);
 const backup=await(await fetch(base+'/api/backup',{headers:{Cookie:ca}})).json();assert.equal(backup.version,1);
 for(const file of ['/','/app.js','/scanner.js','/style.css','/vendor/zxing.js','/manifest.webmanifest'])assert.equal((await fetch(base+file)).status,200,file);
 assert.equal((await fetch(base+'/data/inventory.json')).status,404);
 await post('/api/logout',{},ca);assert.equal((await fetch(base+'/api/state',{headers:{Cookie:ca}})).status,401);
});
