'use strict';
const { chromium }=require('playwright-core');
const http=require('node:http'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
const { createApp }=require('../server');
(async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'toki-browser-')),app=createApp({dir,code:'smoke-test'}),server=http.createServer(app.handler);let browser;
 try{
  await new Promise(r=>server.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${server.address().port}`;
  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,chromiumSandbox:true});
  const errors=[],ca=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true}),cb=await browser.newContext({viewport:{width:412,height:915},isMobile:true,hasTouch:true});
  const a=await ca.newPage(),b=await cb.newPage();for(const p of[a,b])p.on('pageerror',e=>errors.push(e.message));
  async function login(p,name){await p.goto(url);await p.locator('#login-form input[name=name]').fill(name);await p.locator('#login-form input[name=code]').fill('smoke-test');await p.locator('#login-form button').click();await p.locator('#workspace').waitFor({state:'visible'});}
  async function scan(p,code){await p.locator('#barcode').fill(code);await p.locator('#manual-form button').click();}
  async function total(p,n){await p.waitForFunction(n=>document.getElementById('total').textContent===String(n),n);}
  await login(a,'Anna');await login(b,'Béla');await a.locator('#open-inventory').click();await a.locator('#new-form input').fill('Telefonos próbaleltár');await a.locator('#new-form button.primary').click();
  await a.waitForFunction(()=>!document.getElementById('barcode').disabled);await b.waitForFunction(()=>!document.getElementById('barcode').disabled);
  await Promise.all([scan(a,'5904608006127'),scan(b,'5904608006127')]);await total(a,2);await total(b,2);
  await a.locator('#undo').click();await total(a,1);await total(b,1);
  await scan(a,'TEST-123');await a.locator('#product-dialog').waitFor({state:'visible'});
  await a.locator('#product-form input[name=name]').fill('Próba fékbetét');await a.locator('#product-form input[name=brand]').fill('TESZT');await a.locator('#product-form input[name=partNumber]').fill('ABC-123');await a.locator('#save-product').click();await total(a,2);await total(b,2);
  await a.route('**/api/action',async route=>{await route.fetch();await route.abort('failed');},{times:1});
  await scan(a,'5904608006127');await a.locator('#retry-panel').waitFor({state:'visible'});await a.reload();await a.locator('#retry-panel').waitFor({state:'visible'});await a.locator('#retry').click();await total(a,3);await a.locator('#retry-panel').waitFor({state:'hidden'});
  assert.equal(app.store.rows(app.store.data.inventories[0].id).reduce((n,p)=>n+p.quantity,0),3);
  const decoded=await a.evaluate(async()=>{
   const L=['0001101','0011001','0010011','0111101','0100011','0110001','0101111','0111011','0110111','0001011'],G=['0100111','0110011','0011011','0100001','0011101','0111001','0000101','0010001','0001001','0010111'],R=L.map(s=>[...s].map(c=>c==='0'?'1':'0').join(''));
   const code='5904608006127',parity='LGGLLG';let bits='101';for(let i=1;i<7;i++)bits+=(parity[i-1]==='L'?L:G)[Number(code[i])];bits+='01010';for(let i=7;i<13;i++)bits+=R[Number(code[i])];bits+='101';
   const canvas=document.createElement('canvas');canvas.width=(bits.length+24)*4;canvas.height=220;const ctx=canvas.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle='black';[...bits].forEach((bit,i)=>{if(bit==='1')ctx.fillRect((i+12)*4,20,4,180);});
   const reader=new ZXingBrowser.BrowserMultiFormatReader();return(await reader.decodeFromImageUrl(canvas.toDataURL())).getText();
  });assert.equal(decoded,'5904608006127');
  for(const p of[a,b])assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,'mobile viewport overflow');
  await a.screenshot({path:process.env.SCREENSHOT_PATH||path.join(os.tmpdir(),'toki-leltar-mobile.png'),fullPage:true});
  await a.locator('#close-inventory').click();await a.locator('#close-form button.primary').click();await a.waitForFunction(()=>document.getElementById('barcode').disabled);await b.waitForFunction(()=>document.getElementById('barcode').disabled);
  await a.locator('#open-inventory').click();await a.locator('#new-form input').fill('Második leltár');await a.locator('#new-form button.primary').click();await total(a,0);
  assert.equal(app.store.data.products.length,2);assert.equal(app.store.rows(app.store.data.inventories[0].id).reduce((n,p)=>n+p.quantity,0),3);assert.deepEqual(errors,[]);
  console.log('PASS: two mobile browsers, shared counts, undo, unknown product, retry after reload, real EAN decoder, closing, new inventory, mobile layout.');
 }finally{await browser?.close();await new Promise(r=>server.close(r));fs.rmSync(dir,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
